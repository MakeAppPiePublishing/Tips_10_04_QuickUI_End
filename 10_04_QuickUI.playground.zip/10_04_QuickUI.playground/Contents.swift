import UIKit

class ViewController:UIViewController{
    var count =  0
    
    // Add Outlets here as initialized variables
    var label = UILabel.Label(text: "Count: 0", font: .largeTitle)
    
    
    @IBAction func increment(sender:UIButton){
        count += 1
        label.text = "Count \(count)"
    }
    
    @IBAction func decrement(sender:UIButton){
        count += -1
        label.text = "Count \(count)"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
//Adding my UI here.
        let rootStack = UIStackView.VStack(views:[
                UILabel.Label(text: "My QuickUI Test ", font: .largeTitle),
                label,
                UIStackView.HStack(views:[
                    UIButton.Button(title: "Add1", target: self, selector: #selector(increment(sender:))),
                    UIButton.Button(title: "Subtract 1", target: self, selector: #selector(decrement(sender:)))
                ])
            ],alignment: .fill)
        UIStackView.embed(stack: rootStack, in: self.view)
        
    }
    
    // Necessary code for proper working of View Controllers in Playgronds
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .systemBackground
        self.view = view
    }
}





import PlaygroundSupport
let vc = ViewController()
PlaygroundPage.current.liveView = vc


