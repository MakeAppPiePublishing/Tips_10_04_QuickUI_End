// An exercise file for iOS Development Tips Weekly
// A weekely course on LinkedIn Learning for iOS developers
//  Season 10 (Q2 2020) video 04
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
// This Week:  Explore extentions and customizing your UI when prototyping.
//  For more code, go to http://bit.ly/AppPieGithub



import UIKit
public extension UIButton{
    class func Button(title:String, target:Any? , selector:Selector, font:UIFont.TextStyle = . body, textColor:UIColor = .blue, backgroundColor:UIColor = .clear) -> UIButton{
        let button = UIButton()
        button.addTarget(target, action: selector, for:.touchUpInside)
        button.setTitle(title, for: .normal)
        button.setTitleColor(textColor, for: .normal)
        button.backgroundColor = backgroundColor
        button.titleLabel?.font = UIFont.preferredFont(forTextStyle: font)
        return button
    }
}


public extension UILabel{
    class func Label(text:String,font:UIFont.TextStyle = .body, textColor:UIColor = .label, backgroundColor:UIColor = .clear, alignment:NSTextAlignment = .natural)->UILabel{
        let label = UILabel()
        label.text = text
        label.font = UIFont.preferredFont(forTextStyle: font)
        label.textColor = textColor
        label.backgroundColor = backgroundColor
        label.textAlignment = alignment
        return label
    }
}

public extension UIStackView{
    class func VStack(views:[UIView], alignment:UIStackView.Alignment = .fill)->UIStackView{
        let stack = UIStackView(arrangedSubviews: views)
        stack.axis = .vertical
        stack.alignment = alignment
        stack.distribution = .fill
        return stack
    }
    
    class func HStack(views:[UIView],alignment:UIStackView.Alignment = .fill)->UIStackView{
        let stack = UIStackView(arrangedSubviews: views)
        stack.axis = .horizontal
        stack.alignment = alignment
        stack.distribution = .fill
        return stack
    }
    
    class func embed(stack:UIStackView, in view:UIView, padding:CGFloat = 0.0){
        view.addSubview(stack)
        stack.translatesAutoresizingMaskIntoConstraints = false
        var constraints = [NSLayoutConstraint]()
        constraints += [NSLayoutConstraint(item: stack, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1.0, constant: padding)]
        constraints += [NSLayoutConstraint(item: stack, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1.0, constant: padding)]
        constraints += [NSLayoutConstraint(item: stack, attribute: .leading, relatedBy: .equal, toItem: view, attribute: .leading, multiplier: 1.0, constant: padding)]
        constraints += [NSLayoutConstraint(item: stack, attribute: .trailing, relatedBy: .equal, toItem: view, attribute: .trailing, multiplier: 1.0, constant: padding)]
    }
}


